//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func getAirQualityButton(_ sender: Any) {
        // make an api call
        // parse the response
        // Show the proper image based ont the response
        fetchAirQuality()
    }
    
    func fetchAirQuality() {
        // http://api.airvisual.com/v2/city?city=Los Angeles&state=California&country=USA&key={{YOUR_API_KEY}}
        
        // get components for API call
        let apiKey = "75adeb5f-9e8a-42d2-8249-c30647f89bab"
        let city = "Los Angeles"
        let state = "California"
        let country = "USA"
        
        let urlString = "https://api.airvisual.com/v2/city?city=\(city)&state=\(state)&country=\(country)&key=\(apiKey)"
        
        guard let url = URL(string: urlString) else {
            print("Incorrect Website")
            return
        }
        
        // Make API Call
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
 //           print("Data: \(data)")
 //           print("Response: \(response)")
 //           print("Error: \(error )")
            
            // Parse API response
            guard let responseData = data else {
                // Let user know that there is no data
                return
            }
            
            do {
                if let json = try JSONSerialization.jsonObject(with: responseData, options: []) as? [String: Any],
                   let dataFromjson = json["data"] as? [String: Any],
                   let currentFromJason = dataFromjson["current"] as? [String: Any],
                   let pollutionFromJason = currentFromJason["pollution"] as? [String: Any],
                   let aqius = pollutionFromJason["aqius"] as? Int
                {
                    DispatchQueue.main.async {
                        self.showImageForAquiusValue(aqius)
                    }
                }
                
            } catch {
                // Let user know that there is no data
                print ("Error getting json")
            }
        }
        
        task.resume()
        
        // Show the right image
    }
    
    func showImageForAquiusValue(_ value: Int) {
        print("Aq value is: \(value)")
        if (value <= 50) {
            // Show good image
            // myairqualityapp_bitmoji_1
            myImageView.image = UIImage(named: "myairqualityapp_bitmoji_1")
        } else if (value <= 100) {
            // show ok image
            // myairqualityapp_bitmoji_2
            myImageView.image = UIImage(named: "myairqualityapp_bitmoji_2")
        } else {
            // Show bad air quality image
            // myairqualityapp_bitmoji_2
            myImageView.image = UIImage(named: "myairqualityapp_bitmoji_2")
        }
    }
    
}

