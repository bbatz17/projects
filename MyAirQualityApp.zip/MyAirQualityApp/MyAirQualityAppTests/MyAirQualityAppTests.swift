//
//  MyAirQualityAppTests.swift
//  MyAirQualityAppTests
//
//  Created by Brayan Batz on 3/28/25.
//

import Testing
@testable import MyAirQualityApp

struct MyAirQualityAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
